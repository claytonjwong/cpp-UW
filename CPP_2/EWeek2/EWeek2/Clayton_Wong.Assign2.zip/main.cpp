//
//  main.cpp
//  EWeek2
//
//  Created by CLAYTON WONG on 5/3/18.
//  Copyright © 2018 Clayton Wong. All rights reserved.
//

#include <iostream>


using namespace std;

/*
int main(int argc, const char * argv[]) {
    
    
    
    
    return 0;
}
*/

