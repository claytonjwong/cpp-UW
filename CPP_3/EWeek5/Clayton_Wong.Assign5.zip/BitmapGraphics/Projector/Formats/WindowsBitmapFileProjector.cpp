//
//  WindowsBitmapFileProjector.cpp
//  EWeek5
//
//  Created by Clayton Wong on 9/16/18.
//  Copyright © 2018 Clayton Wong. All rights reserved.
//

#include "WindowsBitmapFileProjector.hpp"

namespace BitmapGraphics
{
    void WindowsBitmapFileProjector::projectCanvas ( const HCanvas& canvas ) const
    {
        //
        // TODO
        //
    }
    
} // namespace BitmapGraphics
