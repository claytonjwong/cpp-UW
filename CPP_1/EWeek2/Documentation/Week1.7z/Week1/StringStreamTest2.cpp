#include "TestHarness.h"

#include <sstream>
#include <iostream>

TEST(intToString, stringstream)
{
	std::stringstream message;

	message << 3;

	CHECK_EQUAL("3", message.str());
}

TEST(stringToInt, stringstream)
{
	std::stringstream message("64");

	int value;

	message >> value;

	CHECK_EQUAL(64, value);
}

