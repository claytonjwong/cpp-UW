#include "TestHarness.h"

#include <vector>

TEST(defaultConstructor, vector)
{
	std::vector<int> ages;

	CHECK_EQUAL(0, ages.size());
	CHECK(ages.empty());
}


TEST(initConstructor, vector)
{
	std::vector<int> ages = { 0, 5, 8, 9 };

	CHECK_EQUAL(4, ages.size());

	CHECK_EQUAL(0, ages[0]);
	CHECK_EQUAL(5, ages[1]);
	CHECK_EQUAL(8, ages[2]);
	CHECK_EQUAL(9, ages[3]);
}

TEST(push_back, vector)
{
	std::vector<int> ages;

	ages.push_back(8);

	CHECK_EQUAL(1, ages.size());
	CHECK_EQUAL(8, ages[0]);
}
