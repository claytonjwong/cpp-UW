#include "AddInt.h"

int addInt(int a, int b)
{
	return a + b;
}