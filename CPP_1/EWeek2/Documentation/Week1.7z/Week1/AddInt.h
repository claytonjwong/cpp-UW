#pragma once

int addInt(int a, int b);
