#include "TestHarness.h"

#include "AddInt.h"

TEST(simpleAdd, addInt)
{
	auto result = addInt(5, 6);

	CHECK_EQUAL(11, result);
}