#ifndef MONTHS_H_
#define MONTHS_H_

std::string getMonthsTwoArrays();
std::string getMonthsOneArrayStruct();
#endif