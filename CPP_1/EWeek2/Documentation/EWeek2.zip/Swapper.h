#ifndef SWAPPER_H_
#define SWAPPER_H_

void Swapper(int*,int*);
void Swapper(int&,int&);

#endif