#ifndef CAT_H_
#define CAT_H_

#include <string>

char* cat(char*,char*);
std::string cat(const std::string&,const std::string&);

#endif