#ifndef SWAP_H_ALREADY_INCLUDED
#define SWAP_H_ALREADY_INCLUDED

#pragma once

void swap(int* n1, int* n2);

void swap(int& n1, int& n2);

#endif