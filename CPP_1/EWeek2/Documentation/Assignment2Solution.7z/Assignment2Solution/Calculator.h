#ifndef CALCULATOR_H_ALREADY_INCLUDED
#define CALCULATOR_H_ALREADY_INCLUDED

#pragma once

#include <istream>

std::string Calculator(
    std::istream& input);

#endif