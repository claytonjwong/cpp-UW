#include "SimpleClass.h"

#include <iostream>

int main()
{
    SimpleClass sc;

    f1(sc);

    char ch;
    std::cin.get(ch);
}