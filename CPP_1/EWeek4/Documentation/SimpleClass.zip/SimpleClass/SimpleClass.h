#pragma once

class SimpleClass
{
public:
    SimpleClass();
    SimpleClass(const SimpleClass& src);

    ~SimpleClass();
};

void f1(SimpleClass aSimpleClass);
void f2(SimpleClass aSimpleClass);
void f3(SimpleClass& aSimpleClass);
void f4(SimpleClass* aSimpleClass);

