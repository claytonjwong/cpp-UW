#include "SimpleClass.h"

#include <iostream>

SimpleClass::SimpleClass()
{
    std::cout << "SimpleClass default constructor" << std::endl;
}

SimpleClass::SimpleClass(const SimpleClass& src)
{
    std::cout << "SimpleClass copy constructor" << std::endl;
}

SimpleClass::~SimpleClass()
{
    std::cout << "SimpleClass destructor" << std::endl;
}

void f1(SimpleClass aSimpleClass)
{
    SimpleClass sc;
    f2(sc);
}

void f2(SimpleClass aSimpleClass)
{
    SimpleClass sc(aSimpleClass);
    f3(sc);
}

void f3(SimpleClass& aSimpleClass)
{
    f4(&aSimpleClass);
}

void f4(SimpleClass* aSimpleClass)
{
}