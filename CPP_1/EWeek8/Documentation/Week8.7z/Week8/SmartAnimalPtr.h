#include <ostream>

#pragma once

class Animal
{
public:
	Animal(const std::string& name)
		: myName(name)
	{
	}

	std::string getName() const
	{
		return myName;
	}

	friend std::ostream& operator<<(std::ostream& os, const Animal& a)
	{
		os << a.getName();

		return os;
	}

private:
	std::string myName;
};

class SmartAnimalPtr
{
public:
	SmartAnimalPtr(Animal* ptr)
		: myPtr(ptr)
	{
	}

	SmartAnimalPtr(const SmartAnimalPtr&) = delete;

	SmartAnimalPtr& operator=(const SmartAnimalPtr&) = delete;

	~SmartAnimalPtr()
	{
		delete myPtr;
	}

	Animal* operator->()
	{
		return myPtr;
	}

	Animal& operator*()
	{
		return *myPtr;
	}

	Animal* get()
	{
		return myPtr;
	}

	Animal* release()
	{
		auto ptr = myPtr;
		myPtr = nullptr;
		return ptr;
	}

	void reset(Animal* ptr = nullptr)
	{
		delete myPtr;
		myPtr = ptr;
	}

private:
	Animal* myPtr;
};