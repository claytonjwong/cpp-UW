#include "TestHarness.h"

#include <string>
#include <iostream>
#include <sstream>

class Employee
{
public:
	Employee(const std::string& name)
		: myName(name)
	{
	}

	std::string getName() const
	{
		return myName;
	}

private:
	std::string myName;
};

class IEmployeeWriter
{
public:
	virtual ~IEmployeeWriter() = default;

	virtual void Write(const Employee& e) = 0;
};

class StreamEmployeeWriter: public IEmployeeWriter
{
public:
	StreamEmployeeWriter(std::ostream& os)
		: myOS(os)
	{
	}

	void Write(const Employee& e) override
	{
		myOS << e.getName();
	}

private:
	std::ostream& myOS;
};

void writeEmployee(IEmployeeWriter& writer, const Employee& e)
{
	writer.Write(e);
}

TEST(writer, StreamEmployeeWriter)
{
	std::stringstream stream;

	StreamEmployeeWriter writer(stream);

	Employee e("Steve Jobs");

	writeEmployee(writer, e);

	CHECK_EQUAL("Steve Jobs", stream.str());
}

class XmlEmployeeWriter : public IEmployeeWriter
{
public:
	XmlEmployeeWriter(std::stringstream& ss)
		: mySS(ss)
	{
	}

	void Write(const Employee& e) override
	{
		mySS << "<Employee Name='" << e.getName() << "'></Employee>";
	}

private:
	std::stringstream& mySS;
};

TEST(writer, XmlEmployeeWriter)
{
	std::stringstream stream;

	XmlEmployeeWriter employeeWriter(stream);

	Employee e("Steve Jobs");

	writeEmployee(employeeWriter, e);

	CHECK_EQUAL("<Employee Name='Steve Jobs'></Employee>", stream.str());
}

void reportWriter(IEmployeeWriter& writer, const std::vector<Employee>& employees)
{
	for (auto& employee : employees)
	{
		writer.Write(employee);
	}
}

TEST(ReportWriterWithStream, virtual)
{
	std::vector<Employee> theEmployees;
	theEmployees.push_back(Employee("Charlie Brown"));
	theEmployees.push_back(Employee("Linus"));
	theEmployees.push_back(Employee("Lucy"));

	StreamEmployeeWriter writer(std::cout);

	reportWriter(writer, theEmployees);
}

TEST(ReportWriterWithXml, virtual)
{
	std::vector<Employee> theEmployees;
	theEmployees.push_back(Employee("Charlie Brown"));
	theEmployees.push_back(Employee("Linus"));
	theEmployees.push_back(Employee("Lucy"));

	std::stringstream employeeStream;
	XmlEmployeeWriter writer(employeeStream);

	reportWriter(writer, theEmployees);
}
