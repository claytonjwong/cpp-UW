#include "TestHarness.h"

#include "SmartAnimalPtr.h"

#include <memory>

TEST(ctor, SmartPtr)
{
	SmartAnimalPtr ptr(new Animal("Snoopy"));
}

TEST(pointerOperator, SmartPtr)
{
	SmartAnimalPtr ptr(new Animal("Snoopy"));

	CHECK_EQUAL("Snoopy", ptr->getName());
}

void f(const Animal& a)
{
	// do something with Animal a
}

TEST(dereferenceOperator, SmartPtr)
{
	SmartAnimalPtr ptr(new Animal("Snoopy"));

	f(*ptr);
}

void f2(const Animal* a)
{
	// do something with Animal a
}

TEST(passToPointerToAnimal, SmartPtr)
{
	SmartAnimalPtr ptr(new Animal("Snoopy"));

	f2(ptr.get());
}

TEST(release, SmartPtr)
{
	SmartAnimalPtr ptr(new Animal("Snoopy"));

	auto iOwnThePtrNow = ptr.release();

	delete iOwnThePtrNow;
}

TEST(reset, SmartPtr)
{
	SmartAnimalPtr ptr(new Animal("Snoopy"));

	// use the ptr
	// ...

	ptr.reset(new Animal("Hobbes"));

	CHECK_EQUAL("Hobbes", ptr->getName());
}

TEST(resetToClear, SmartPtr)
{
	SmartAnimalPtr ptr(new Animal("Snoopy"));

	// use the ptr
	// ...

	ptr.reset();
#if 0
	CHECK_EQUAL(nullptr, ptr.get());
#endif
}

TEST(move, unique_ptr)
{
	auto p1 = std::make_unique<int[]>(40);

	// ...

	auto p2 = std::make_unique<int[]>(56);

	// copy values from p1 to p2

	p1 = std::move(p2);
}

void f4(std::unique_ptr<int[]> p)
{
	// use p

	// delete p
}

TEST(moveByValue, unique_ptr)
{
	auto p1 = std::make_unique<int[]>(40);

	// ...
	f4(std::move(p1));
}
