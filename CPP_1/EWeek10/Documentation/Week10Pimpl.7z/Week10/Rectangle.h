#pragma once

#include <ostream>
#include <memory>

struct Point
{
    Point()
        : x(-1), y(-x)
    {

    }

    Point(int x, int y)
        : x(x), y(x)
    {
    }

    bool operator==(const Point& rhs)
    {
        return rhs.x == x && rhs.y == y;
    }

    bool operator!=(const Point& rhs)
    {
        return !operator==(rhs);
    }

    friend std::ostream& operator<<(std::ostream& os, const Point& p)
    {
        os << p.x << "," << p.y;
        return os;
    }

    int x;
    int y;
};

#if 0
class Rectangle
{
public:
    Rectangle(const Point& upperLeft, const Point& lowerRight);

    Point getUpperLeft() const;
    Point getLowerRight() const;

private:
    Point myUpperLeft;
    Point myLowerRight;
};

class Rectangle
{
public:
    Rectangle(const Point& upperLeft, const Point& lowerRight);
    ~Rectangle();

    Point getUpperLeft() const;
    Point getLowerRight() const;

private:
    struct Impl;
    Impl* myImpl;
};
#else
class Rectangle
{
public:
    Rectangle(const Point& upperLeft, const Point& lowerRight);
    ~Rectangle();

    Point getUpperLeft() const;
    Point getLowerRight() const;

private:
    struct Impl;
    std::unique_ptr<Impl> myImpl;
};
#endif