#include "TestHarness.h"

#include "Rectangle.h"

TEST(PIMPL, virtual)
{
    Rectangle r(Point(10, 10), Point(100, 100));

    CHECK_EQUAL(Point(10, 10), r.getUpperLeft());
    CHECK_EQUAL(Point(100, 100), r.getLowerRight());
}

