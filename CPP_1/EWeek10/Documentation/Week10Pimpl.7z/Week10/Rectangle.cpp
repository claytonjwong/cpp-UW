#include "Rectangle.h"

#if 0
Rectangle::Rectangle(const Point& upperLeft, const Point& lowerRight)
    : myUpperLeft(upperLeft), myLowerRight(lowerRight)
{
}

Point Rectangle::getUpperLeft() const
{
    return myUpperLeft;
}

Point Rectangle::getLowerRight() const
{
    return myLowerRight;
}
#else
struct Rectangle::Impl
{
    Point myUpperLeft;
    Point myLowerRight;
    int myArea;
};

Rectangle::Rectangle(const Point& upperLeft, const Point& lowerRight)
    : myImpl(std::make_unique<Impl>())
{
    myImpl->myUpperLeft = upperLeft;
    myImpl->myLowerRight = lowerRight;
}

Rectangle::~Rectangle()
{
}

Point Rectangle::getUpperLeft() const
{
    return myImpl->myUpperLeft;
}

Point Rectangle::getLowerRight() const
{
    return myImpl->myLowerRight;
}
#endif