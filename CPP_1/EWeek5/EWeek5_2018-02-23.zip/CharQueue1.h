/*

1. CharQueue1 with a char* array as the private data member.
Use new to grow the array used for the queue as needed. Add other private member variables
as needed to track size and position.  Overload the copy constructor and assignment operator
to and implement a deep copy.


[Clayton]: Sure, I will plan to use the following variables to keep track of the char array:

curr <= cnt <= sz ( curr is less than or eq to cnt is less than or eq to sz )

* curr is the current index within q which is next-in-line to be dequeued
( curr is incremented by 1 for each dequeue, and is reset to 0 when q is empty )

* cnt is the amount of valid enqueued chars
( cnt is incremented by 1 for each enqueue, and is reset to 0 when q is empty )

* sz is the size of the array.  its value can be thought of as
an imaginary index one-past the last valid index of the array,
similiar to end() with iterators


Base on these definitions, it follows that:

* if curr eq cnt, then the q is empty 
* if cnt eq sz, then q is full


And I will assume we are NOT in a memory constrained environment.  So I will allow the size
of the array to remain as the largest size it has grown to.
( i.e. each resize will only make the array bigger )

*/

#pragma once

#include <memory>

class CharQueue1 {
public:
	/* constructors */
	CharQueue1() : curr(0),cnt(0),sz(DEFAULT_SIZE),q(new char[sz]) {}
	CharQueue1(size_t size) : curr(0),cnt(0),sz(size),q(new char[size]) {}
	CharQueue1(const CharQueue1& src) : curr(0),cnt(src.cnt),sz(src.capacity()),q(new char[sz]) {
		for (int i=0; i<src.cnt; ++i) q[i]=src.q[i];
	}

	/* accessors */
	bool isEmpty() const { return curr==cnt; }
	bool isFull()  const { return cnt==sz; }
	int capacity() const { return sz; } // size of internal array structure
	//
	// the following capacity() function returns the same value as CharQueue2 would
	// ( i.e. the actual amount of elements stored in the q ), however I found it more helpful
	// for CharQueue1 to return the size of the internal char[] structure in order to ensure
	// that it grows exponentially
	//
	//int capacity() const { return cnt-curr;  } // amount of chars currently pushed on the q

	/* mutators */
	void enqueue(char ch);
	char dequeue();
	void swap(CharQueue1& src);

	/* operators */
	CharQueue1& operator=(CharQueue1 src);
	
private:
	const int DEFAULT_SIZE=1;
	int curr,cnt,sz;
	std::unique_ptr<char[]> q;

	void sink(std::unique_ptr<char[]> releaseMe) {}
	void resize();
};


